namespace DontStarveTogetherBot.Models;

public class Config
{
    public string CqWsAddress = "ws://127.0.0.1:8080";
    public string Region = "Sing";
    public string Event = "noevent";
    public string KLeiToken = "exampleToken";
    public string DstServerIp = "";
    public int DstServerPort = 10999;
}