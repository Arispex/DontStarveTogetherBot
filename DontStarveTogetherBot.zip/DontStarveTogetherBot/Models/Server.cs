using System.IO.Compression;
using System.Text.Json;
using YamlDotNet.Serialization;

namespace DontStarveTogetherBot.Models;

public class Server
{
    public string Ip { get; set; }
    public int Port { get; set; }
    
    public Server(string ip, int port)
    {
        this.Ip = ip;
        this.Port = port;
    }

    public async ValueTask<string> GetRowIdAsync()
    {
        var configPath = Path.Combine(AppContext.BaseDirectory, "config.yaml");
        var config = new Deserializer().Deserialize<Config>(await File.ReadAllTextAsync(configPath));

        var url = $"https://lobby-cdn.klei.com/{config.Region}-Steam-{config.Event}.json.gz";
        using var httpClient = new HttpClient();
        var response = await httpClient.GetAsync(url);
        var stream = new GZipStream(await response.Content.ReadAsStreamAsync(), CompressionMode.Decompress);
        var serverList = await JsonSerializer.DeserializeAsync<ServerList>(stream, new JsonSerializerOptions()
        {
            PropertyNameCaseInsensitive = true
        });
        Console.WriteLine(serverList.ServerInfos == null);
        return "";
    }
}