using System.Text.Json.Serialization;

namespace DontStarveTogetherBot.Models;

public class ServerInfo
{
        [JsonPropertyName("__addr")]
        public string Addr { get; set; }

        [JsonPropertyName("__lastPing")]
        public long LastPing { get; set; }

        [JsonPropertyName("__rowId")]
        public string RowId { get; set; }

        [JsonPropertyName("host")]
        public string? Host { get; set; }

        [JsonPropertyName("clanonly")]
        public bool Clanonly { get; set; }

        [JsonPropertyName("platform")]
        public long Platform { get; set; }

        [JsonPropertyName("mods")]
        public bool Mods { get; set; }

        [JsonPropertyName("name")]
        public string Name { get; set; }

        [JsonPropertyName("pvp")]
        public bool Pvp { get; set; }

        [JsonPropertyName("session")]
        public string Session { get; set; }

        [JsonPropertyName("fo")]
        public bool? Fo { get; set; }

        [JsonPropertyName("password")]
        public bool Password { get; set; }

        [JsonPropertyName("guid")]
        public string Guid { get; set; }

        [JsonPropertyName("maxconnections")]
        public long Maxconnections { get; set; }

        [JsonPropertyName("dedicated")]
        public bool Dedicated { get; set; }

        [JsonPropertyName("clienthosted")]
        public bool Clienthosted { get; set; }

        [JsonPropertyName("connected")]
        public long Connected { get; set; }

        [JsonPropertyName("mode")]
        public string Mode { get; set; }

        [JsonPropertyName("port")]
        public long Port { get; set; }

        [JsonPropertyName("v")]
        public long V { get; set; }

        [JsonPropertyName("tags")]
        public string Tags { get; set; }

        [JsonPropertyName("season")]
        public string Season { get; set; }

        [JsonPropertyName("lanonly")]
        public bool Lanonly { get; set; }

        [JsonPropertyName("intent")]
        public string Intent { get; set; }

        [JsonPropertyName("desc")]
        public string? Desc { get; set; }

        [JsonPropertyName("tick")]
        public long? Tick { get; set; }

        [JsonPropertyName("clientmodsoff")]
        public bool? Clientmodsoff { get; set; }

        [JsonPropertyName("nat")]
        public long? Nat { get; set; }

        [JsonPropertyName("allownewplayers")]
        public bool Allownewplayers { get; set; }

        [JsonPropertyName("valvecloudserver")]
        public bool? Valvecloudserver { get; set; }

        [JsonPropertyName("valvepopid")]
        public string? Valvepopid { get; set; }

        [JsonPropertyName("valveroutinginfo")]
        public string? Valveroutinginfo { get; set; }

        [JsonPropertyName("serverpaused")]
        public bool Serverpaused { get; set; }

        [JsonPropertyName("mods_info")]
        public List<string>? ModsInfo { get; set; }

        [JsonPropertyName("data")]
        public string? Data { get; set; }

        [JsonPropertyName("worldgen")]
        public string? Worldgen { get; set; }

        [JsonPropertyName("players")]
        public string? Players { get; set; }

        [JsonPropertyName("steamid")]
        public string Steamid { get; set; }

        [JsonPropertyName("steamroom")]
        public string Steamroom { get; set; }

        [JsonPropertyName("Users")]
        public object? Users { get; set; }
}